/**********************************************************
 *                                                        *
 * CSCI 502           Assignment-7      Summer 2023       *
 *                 (Graduate Project)                     *
 * Developers:Vikramaditya Reddy Varkala                  *
 *                                                        *
 * Due Date:08/10/2023                                    *
 *                                                        *
 * Purpose: Responsible for launching the program.        *
 *                                                        *
 **********************************************************/

package com.example.finalproject;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;


public class SortAnimationApp extends Application
{

    @Override
    public void start(Stage stage) throws IOException
    {
        //loads Sorting.fxml file
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Sorting.fxml"));
        Parent root = fxmlLoader.load();

        //Initializes the main scene and shows the stage.
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }



    public static void main(String[] args)
    {
        launch();
    }
}