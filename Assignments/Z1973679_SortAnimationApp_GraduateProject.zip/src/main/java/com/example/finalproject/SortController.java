/**********************************************************
 *                                                        *
 * CSCI 502           Assignment-7      Summer 2023       *
 *                  (Graduate Project)                    *
 * Developers:Vikramaditya Reddy Varkala                  *
 *                                                        *
 * Due Date:08/10/2023                                    *
 *                                                        *
 * Purpose: To manage the user interface and              *
 *          handle user interactions.                     *
 *                                                        *
 **********************************************************/

package com.example.finalproject;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.net.URL;
import java.util.ResourceBundle;

public class SortController implements Initializable, SortAnimation.OnSortCompleteListener
{

    @FXML //for selecting sorts and speed
    private ChoiceBox<String> selectSort1, selectSort2, selectSpeed;

    @FXML //populate and sort button
    private Button populateButton, sortButton;

    @FXML //areas where visualisations are displayed
    private AnchorPane area1, area2;

    @FXML
    private Button pauseResumeButton; //pause and resume button
    private SortAnimation sortAnimation1, sortAnimation2;
    private ExecutorService executorService; //manages threads for executing the selected sort
    private int completedSorts = 0;  //keeps track of how many sorts are completed

    @Override
    public void initialize(URL url, ResourceBundle rb)
    {
        executorService = Executors.newFixedThreadPool(2); //executor service with 2 threads

        //Populates the choice boxes with sorting algorithm names.
        selectSort1.getItems().addAll("","Selection Sort", "Insertion Sort", "Quick Sort");
        selectSort2.getItems().addAll("","Selection Sort", "Insertion Sort", "Quick Sort");

        //Populates the choice boxes with speed.
        selectSpeed.getItems().addAll("Slow", "Medium", "Fast");

        //Sets default values for choice boxes.
        selectSort1.setValue("");
        selectSort2.setValue("");
        selectSpeed.setValue("Slow");

        //Initializes the pause/resume button's text and action.
        pauseResumeButton.setText("Pause"); // Sets the initial text for the button
        pauseResumeButton.setOnAction(event -> pauseOrResume());
    }

    @FXML
    public void populate()
    {
        //Initializes two SortAnimation objects with default speed and area sizes.
        sortAnimation1 = new SortAnimation(area1, 100, selectSort1.getValue(), this); // Default speed
        sortAnimation2 = new SortAnimation(area2, 100, selectSort2.getValue(), this); // Default speed

        //Calls populateArray to fill the arrays in both SortAnimation objects.
        sortAnimation1.populateArray((int) area1.getWidth(), (int) area1.getHeight());
        sortAnimation2.populateArray((int) area2.getWidth(), (int) area2.getHeight());

        //Enables the sort button and disables the populate button.
        sortButton.setDisable(false);
        populateButton.setDisable(true);
    }

    @FXML
    // method to handle pause/resume
    // I have used separate button for pause and resume to the UI user friendly,
    // Sort button is disabled when pause/resume is enabled
    public void pauseOrResume()
    {
        //Changes the text of the pause/resume button to pause and resume animation.
        if (sortAnimation1.isPaused() && sortAnimation2.isPaused())
        {
            sortAnimation1.resume();
            sortAnimation2.resume();
            pauseResumeButton.setText("Pause");
        }
        else
        {
            sortAnimation1.pause();
            sortAnimation2.pause();
            pauseResumeButton.setText("Resume");
        }
    }

    @FXML
    public void sort()
    {
        //Retrieves the speed from the selected value in the selectSpeed choice box.
        long speed = getSpeed();

        //Sets the delay in both SortAnimation objects.
        sortAnimation1.setDelay(speed);
        sortAnimation2.setDelay(speed);

        //Submits both SortAnimation objects to the executor service for execution.
        executorService.submit(sortAnimation1);
        executorService.submit(sortAnimation2);

        //Disables the sort button and enables the pause/resume button.
        sortButton.setDisable(true);
        pauseResumeButton.setDisable(false);
    }

    @Override
    public void onSortComplete()
    {
        completedSorts++;//Increments the count of completed sorts.

        //if both sorts are complete
        if (completedSorts == 2)
        {
            completedSorts = 0; // reset the count for next sorting
            pauseResumeButton.setDisable(true); // disable the pauseResumeButton
            populateButton.setDisable(false); // enables the populate button.
        }
    }


    private long getSpeed()
    {
        //Returns the delay time based on the selected speed.
        //smaller the number, faster the animation.
        return switch (selectSpeed.getValue())
        {
            case "Slow" -> 200;
            case "Fast" -> 10;
            default -> 100; //medium speed
        };
    }
}