/**********************************************************
 *                                                        *
 * CSCI 502           Assignment-7      Summer 2023       *
 *                 (Graduate Project)                     *
 * Developers:Vikramaditya Reddy Varkala                  *
 *                                                        *
 * Due Date:08/10/2023                                    *
 *                                                        *
 * Purpose: To implement the logic for visualizing        *
 *          different sorting algorithms.                 *
 *                                                        *
 **********************************************************/

package com.example.finalproject;

import javafx.application.Platform;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;

import java.util.Random;
import java.util.concurrent.TimeUnit; //provides methods to perform delay operations.

public class SortAnimation implements Runnable
{

    private int[] array; // array to be sorted.
    private final Pane pane; //pane on which to draw the lines representing the array values.
    private long delay; //delay between animation steps.
    private final String sortMethod; // sorting method name
    private final OnSortCompleteListener listener; //An interface to notify when sorting is complete.
    private boolean isPaused = false; //checks whether the sorting is paused.


    public interface OnSortCompleteListener //interface
    {
        void onSortComplete();
    }

    //Initializes fields.
    public SortAnimation(Pane pane, long delay, String sortMethod, OnSortCompleteListener listener)
    {
        this.pane = pane;
        this.delay = delay;
        this.sortMethod = sortMethod;
        this.listener = listener;
    }


    public void setDelay(long delay)
    {
        this.delay = delay;
    }


    @Override
    //Executes the sorting algorithm.
    public void run()
    {
        switch (sortMethod)
        {
            case "Selection Sort":
                selectionSort(array);
                break;
            case "Insertion Sort":
                insertionSort(array);
                break;
            case "Quick Sort":
                quickSort(array, 0, array.length - 1);
                break;
        }
        Platform.runLater(listener::onSortComplete);
    }

    //Populates the array with random values and scales them.
    public void populateArray(int size, int maxValue)
    {
        Random rand = new Random();
        array = new int[size];
        int max = 0;
        for (int i = 0; i < size; i++)
        {
            array[i] = rand.nextInt(maxValue);
            if(array[i] > max){
                max = array[i];
            }
        }

        //i have used padding so that to prevent animation from being drawn out of area 1 and area2 panes
        double scale = (pane.getHeight()-1)/max; // Subtracting 1 for padding
        for(int i = 0; i < size; i++)
        {
            array[i] = (int)(array[i]*scale);
        }

        drawLines();//Calls drawLines to draw the lines.
    }


    public void drawLines()
    {
        //Draws new lines representing the current state of the array.
        pane.getChildren().clear(); //Clears previous lines from the pane(area1 and area2).
        double scale = pane.getWidth() / array.length;
        for (int i = 0; i < array.length; i++)
        {
            Line line = new Line(i * scale, pane.getHeight()-1, i * scale, pane.getHeight() - array[i] - 1); // Subtract 1 for padding
            line.setStroke(Color.BLUE);
            pane.getChildren().add(line);
        }
    }


    // SelectionSort
    public void selectionSort(int[] arr)
    {
        for (int i = 0; i < arr.length - 1; i++)
        {
            int min_idx = i;
            for (int j = i + 1; j < arr.length; j++)
                if (arr[j] < arr[min_idx])
                    min_idx = j;

            int temp = arr[min_idx];
            arr[min_idx] = arr[i];
            arr[i] = temp;
            drawWithDelay();//to update visualisation
        }
    }


    // InsertionSort
    public void insertionSort(int[] arr)
    {
        for (int i = 1; i < arr.length; ++i)
        {
            int key = arr[i];
            int j = i - 1;
            while (j >= 0 && arr[j] > key)
            {
                arr[j + 1] = arr[j];
                j = j - 1;
            }
            arr[j + 1] = key;
            drawWithDelay();//to update visualisation
        }
    }


    // QuickSort
    public void quickSort(int[] arr, int low, int high)
    {
        if (low < high) {
            int pi = partition(arr, low, high);
            quickSort(arr, low, pi - 1);
            quickSort(arr, pi + 1, high);
        }
    }

    private int partition(int[] arr, int low, int high)
    {
        int pivot = arr[high];
        int i = (low - 1);
        for (int j = low; j <= high - 1; j++)
        {
            if (arr[j] < pivot)
            {
                i++;
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
        int temp = arr[i + 1];
        arr[i + 1] = arr[high];
        arr[high] = temp;
        drawWithDelay();//to update visualisation
        return (i + 1);
    }


    public void pause()
    {
        isPaused = true;
    }


    public boolean isPaused() // getter for the pause state
    {
        return isPaused;
    }


    //  method to allow resuming the animation
    public void resume() {
        synchronized (this) {
            isPaused = false;
            notifyAll();
        }
    }


    private void drawWithDelay()
    {
        try
        {
            Platform.runLater(this::drawLines);
            synchronized (this)
            {
                TimeUnit.MILLISECONDS.sleep(delay);
                while (isPaused)   //If the animation is paused, waits until it's resumed.
                {
                    wait();
                }
            }
        }

        catch (InterruptedException e)
        {
            e.printStackTrace();
        }
    }

}
